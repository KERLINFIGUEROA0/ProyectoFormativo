import { BrowserRouter, Routes, Route } from "react-router-dom";
import LoginPage from "../pages/LoginPage";
import RecuperarPage from "../pages/RecuperarPage";
import ResetPasswordSent from "../pages/ResetPasswordSent";
import NuevaContraseñaPage from "../pages/NuevaContraseña";

export default function AppRouter() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Ruta principal */}
        <Route path="/" element={<LoginPage />} />
        {/* Ruta para recuperar contraseña */}
        <Route path="/recuperar" element={<RecuperarPage />} />
        {/* Ruta para link de recuperacion */}
        <Route path="/send" element={<ResetPasswordSent />} />
        {/* Página actualizar contraseña */}
        <Route path="/restablecer" element={<NuevaContraseñaPage />} />{" "}
        {/* 👈 agrega esto */}
        <Route path="*" element={<h1>404 - Página no encontrada</h1>} />
      </Routes>
    </BrowserRouter>
  );
}
