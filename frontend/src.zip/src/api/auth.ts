import axios from "axios";

const API_URL = import.meta.env.VITE_BACKEND_URL;

// Login
export const login = async (identifier: string, password: string) => {
  const res = await axios.post(`${API_URL}/auth/login`, {
    identificacion: identifier,
    password,
  });
  return res.data;
};

// Recuperar contraseña
export const solicitarRecuperacion = async (identificacion: string) => {
  const res = await axios.post(`${API_URL}/recuperacion/solicitar`, {
    identificacion,
  });
  return res.data;
};

// Verificar token
export const verificarToken = async (token: string) => {
  const res = await axios.get(`${API_URL}/recuperacion/verificar/${token}`);
  return res.data;
};

// Restablecer contraseña
// Restablecer contraseña
export const restablecerPassword = async (token: string, nueva: string) => {
  const res = await axios.post(`${API_URL}/recuperacion/restablecer`, {
    token,
    nueva,
  });
  return res.data;
};
