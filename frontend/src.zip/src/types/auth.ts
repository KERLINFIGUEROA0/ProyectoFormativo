export interface LoginData {
  identificacion: string; // documento
  password: string;
}

// Datos del usuario
export interface UsuarioData {
  tipo: string;
  identificacion?: number;
  nombres: string;
  apellidos: string;
  email: string;
  telefono?: number;
}
// Datos de un usuario en la gestión  
export interface GestionUsuarioData {
  id: number;
  tipo?: string;
  nombre: string;
  apellidos?: string;
  correo: string;
  telefono: number;
  rol: string;
  permisos?: Record<string, boolean>;
}

// Datos de un rol en la gestión
export interface GestionRolData {
  id: number;
  nombre: string;
  descripcion?: string;
  usuariosAsignados?: number;
  permisos?: Record<string, boolean>;
}