import { Card, CardBody, Input, Button } from "@heroui/react";
import { Lock } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { type ChangeEvent, type ReactElement, useState } from "react";
import logo from "../assets/logo.png";
import { solicitarRecuperacion } from "../api/auth";

export default function ResetPasswordForm(): ReactElement {
  const navigate = useNavigate();
    const [identificacion, setIdentificacion] = useState<number | null>(null);

const handleReset = async (): Promise<void> => {
  if (!identificacion) return;
  try {
    const res = await solicitarRecuperacion(String(identificacion));
    // guardar correo en el state o localStorage para mostrarlo después
    localStorage.setItem("correo_recuperacion", res.correo || "correo no disponible");
    navigate("/send");
  } catch (err: any) {
    console.error(err.response?.data || err.message);
    alert("Error al solicitar recuperación");
  }
};


  return (
    <div className="w-full max-w-2xl">
      <Card className="shadow-2xl rounded-2xl bg-white/95 border border-green-200">
        <CardBody className="flex flex-col gap-6 p-8 md:p-12">

          <div className="flex items-center gap-4">
            <img src={logo} alt="Logo" className="h-14" />
            <h1 className="text-2xl md:text-2xl font-extrabold text-gray-800 flex items-center gap-2">
              <Lock className="w-6 h-6 text-gray-700" />
              Restablecimiento de contraseña
            </h1>
          </div>

          <p className="text-sm text-gray-600">Ingresa tu número de identificación.</p>

          <div className="w-full">
            <Input
              type="number"
              label="Número de identificación"
              variant="bordered"
              size="lg"
              fullWidth
              className="h-14 text-lg px-4"
         value={identificacion !== null ? String(identificacion) : ""}
              onChange={(e: ChangeEvent<HTMLInputElement>) => {
                const v = e.target.value;
                setIdentificacion(v === "" ? null : Number(v));
              }}
            />
          </div>

          <div className="pt-2">
            <Button
              color="success"
              size="lg"
              fullWidth
              onPress={handleReset}
              className="rounded-lg bg-green-600 hover:bg-green-700 shadow-md text-white"
            >
              Restablecer
            </Button>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
