import { useState, type ChangeEvent, type ReactElement } from "react";
import { Input, Button, Card, CardBody } from "@heroui/react";
import { useNavigate, Link } from "react-router-dom";
import logo from "../assets/logo.png";
import type { LoginData } from "../types/auth";

export default function LoginForm(): ReactElement {
  const navigate = useNavigate();

  // Estado para inputs
  const [formData, setFormData] = useState<LoginData>({
    identificacion: "",
    password: "",
  });

  // Estado para mostrar/ocultar contraseña
  const [isVisible, setIsVisible] = useState<boolean>(false);
  const toggleVisibility = (): void => setIsVisible((v) => !v);

  const handleLogin = (): void => {
    // Aquí iría validación real
    console.log("Datos de login:", formData);
    navigate("/home");
  };

  return (
    <Card className="w-full max-w-sm shadow-2xl rounded-2xl bg-white border border-green-100">
      <CardBody className="flex flex-col gap-4 p-8">
        {/* Logo */}
        <div className="flex justify-center">
          <img src={logo} alt="Logo" className="h-20" />
        </div>

        {/* Título */}
        <h1 className="text-center text-2xl font-extrabold">Iniciar sesión</h1>

        <Input
          label="Documento"
          type="number"
          variant="bordered"
          size="md"
          fullWidth
          className="h-11 text-sm px-3"
          value={formData.identificacion}
          onChange={(e: ChangeEvent<HTMLInputElement>) =>
            setFormData({ ...formData, identificacion: e.target.value })
          }
        />

        <Input
          label="Contraseña"
          type={isVisible ? "text" : "password"}
          variant="bordered"
          size="md"
          fullWidth
          className="h-11 text-sm px-3"
          value={formData.password}
          onChange={(e: ChangeEvent<HTMLInputElement>) =>
            setFormData({ ...formData, password: e.target.value })
          }
          endContent={
            <button
              type="button"
              onClick={toggleVisibility}
              className="focus:outline-none"
            ></button>
          }
        />

        <Link
          to="/recuperar"
          className="text-xs text-gray-500 hover:underline self-start"
        >
          ¿Olvidaste tu contraseña?
        </Link>

        <Button
          color="success"
          size="lg"
          fullWidth
          onPress={handleLogin}
          className="rounded-lg bg-green-600 hover:bg-green-700 shadow-md text-white"
        >
          Ingresar
        </Button>
      </CardBody>
    </Card>
  );
}
